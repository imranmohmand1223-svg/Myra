MYRA Android project — APK build karne ka asaan tareeqa

IMPORTANT:
- Ye Android source project hai, APK abhi is ZIP mein included nahi.
- Ye MYRA ka naya prototype hai, official third-party MYRA app nahi.
- AI chat ke liye apni Gemini API key aur internet chahiye. API key ko kisi ke saath share na karein. Personal test ke liye hi is prototype ko use karein.
- Urdu voice recognition aur speech phone ke speech services/language packs par depend karti hai.
- Phone ke tamam settings ko voice se control karna is version mein supported nahi.

APK banane ke liye (computer ke baghair bhi mumkin, lekin GitHub account chahiye):
1. github.com par sign in/create account karo.
2. New repository banao, naam MYRA rakh do.
3. Is ZIP ko extract karo. Andar ke tamam files/folders ko repository mein upload karo. .github folder bhi upload hona zaroori hai.
4. GitHub repository mein Actions tab kholo.
5. Agar workflow manual run ka option aaye to "Build MYRA APK" select karke "Run workflow" dabao. Warna main/master branch par files upload karne se workflow khud chal sakta hai.
6. Green check ke baad workflow run kholo. Neeche Artifacts mein "MYRA-debug-APK" download karo.
7. ZIP artifact extract karo; uske andar app-debug.apk hoga. Apne Android phone par transfer karke install karo. Android poochay to sirf apne trusted APK ke liye browser/file manager ko install permission do.
8. Agar workflow fail ho, error ka screenshot ya log share karo taake fix kiya ja sake.

GitHub file upload:
- Add file > Upload files.
- ZIP ko GitHub web page par directly upload karne se project build nahi hota; pehle ZIP extract karke files upload karo.
- .github/workflows/build-apk.yml ko bhi repository mein hona chahiye.

AI setup:
- Google AI Studio se apni Gemini API key banao. API key ko public repository ya social media par kabhi paste na karo.
- App ke andar key field mein enter karo. Ye demo key ko screen mein rakhta hai, securely encrypted store nahi karta; app close hone par key dobara enter karni pad sakti hai.
