package com.myra.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var log: LinearLayout
    private lateinit var input: EditText
    private lateinit var apiKey: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val bg = Color.rgb(7, 17, 31)
    private val cyan = Color.rgb(98, 234, 255)
    private val panel = Color.rgb(16, 31, 49)
    private val white = Color.rgb(237, 250, 255)
    private val muted = Color.rgb(157, 178, 199)
    private val reqSpeech = 1001
    private val reqMic = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val logo = TextView(this).apply {
            text = "◉  M Y R A"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setPadding(0, dp(14), 0, dp(4))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(logo, matchWrap())
        content.addView(TextView(this).apply {
            text = "YOUR PERSONAL VOICE ASSISTANT"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, 0, 0, dp(18))
        }, matchWrap())

        val keyLabel = label("Gemini API key (optional — needed for AI answers)")
        content.addView(keyLabel)
        apiKey = EditText(this).apply {
            hint = "Paste your own API key"
            textSize = 14f
            setSingleLine(true)
            setHintTextColor(muted)
            setTextColor(white)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
            inputType = 129
        }
        content.addView(apiKey, matchWrap())
        content.addView(TextView(this).apply {
            text = "For privacy, this demo keeps the key only in this screen; do not share the APK or key."
            textSize = 11f; setTextColor(muted); setPadding(0, dp(5), 0, dp(10))
        }, matchWrap())

        val chatCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatCard.addView(log, matchWrap())
        addBubble("Assalam-o-alaikum! Main MYRA hoon. Urdu mein likho ya mic dabao. AI answers ke liye apni Gemini API key add karo.", false)
        content.addView(chatCard, matchWrap())

        input = EditText(this).apply {
            hint = "Yahan message likho..."
            textSize = 15f
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
        }
        content.addView(input, matchWrap())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; }
        row.addView(button("Send") { sendText() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(8), dp(5), 0) })
        row.addView(button("🎙 Speak") { startListening() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(5), dp(8), 0, 0) })
        content.addView(row, matchWrap())

        content.addView(label("QUICK APP COMMANDS"))
        val appRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("YouTube", "WhatsApp", "Chrome").forEach { app ->
            appRow.addView(button(app) { openApp(app) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
        }
        content.addView(appRow, matchWrap())
        content.addView(TextView(this).apply {
            text = "Note: voice recognition and Urdu speech depend on the phone's installed speech services. This prototype cannot control every phone setting."
            textSize = 11f; setTextColor(muted); setPadding(0, dp(12), 0, dp(8))
        }, matchWrap())

        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts.setLanguage(Locale("ur", "PK"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
        }
    }

    private fun sendText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        addBubble(text, true)
        val q = text.lowercase(Locale.ROOT)
        when {
            q.contains("youtube") -> { openApp("YouTube"); reply("YouTube kholne ki koshish kar rahi hoon.") }
            q.contains("whatsapp") -> { openApp("WhatsApp"); reply("WhatsApp kholne ki koshish kar rahi hoon.") }
            q.contains("chrome") || q.contains("google kholo") -> { openApp("Chrome"); reply("Chrome kholne ki koshish kar rahi hoon.") }
            apiKey.text.toString().trim().isNotEmpty() -> askGemini(text, apiKey.text.toString().trim())
            else -> reply("Main basic commands kar sakti hoon. AI jawab ke liye Gemini API key add karo.")
        }
    }

    private fun askGemini(question: String, key: String) {
        addBubble("Soch rahi hoon…", false)
        thread {
            var answer = "AI service se jawab nahi mil saka. API key aur internet check karo."
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val prompt = "You are MYRA, a helpful assistant. Reply in simple Urdu or Roman Urdu matching the user's language. Be concise and safe. User says: $question"
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                answer = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text")?.takeIf { it.isNotBlank() } ?: answer
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread { addBubble(answer, false); speak(answer) }
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqMic)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "MYRA ko apna command bolo")
            }
            startActivityForResult(intent, reqSpeech)
        } catch (_: Exception) {
            reply("Is phone par speech recognition service available nahi lag rahi.")
        }
    }

    @Deprecated("Android compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); sendText() }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqMic && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == reqMic) reply("Voice use karne ke liye microphone permission allow karo.")
    }

    private fun openApp(name: String) {
        val packageName = when(name) {
            "YouTube" -> "com.google.android.youtube"
            "WhatsApp" -> "com.whatsapp"
            else -> "com.android.chrome"
        }
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            try { startActivity(launch) } catch (_: Exception) { reply("$name open nahi ho saka.") }
        } else {
            val url = when(name) {
                "YouTube" -> "https://www.youtube.com"
                "WhatsApp" -> "https://wa.me"
                else -> "https://www.google.com"
            }
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
        }
    }

    private fun reply(text: String) { addBubble(text, false); speak(text) }
    private fun speak(text: String) {
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myra-utterance")
    }
    private fun addBubble(text: String, user: Boolean) {
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(white)
            setPadding(dp(11), dp(9), dp(11), dp(9))
            setBackgroundColor(if (user) Color.rgb(18, 62, 82) else Color.rgb(20, 43, 64))
        }
        val lp = LinearLayout.LayoutParams(if (user) dp(290) else ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (user) Gravity.END else Gravity.START
        lp.setMargins(0, 0, 0, dp(8))
        log.addView(bubble, lp)
    }
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 11f; setTextColor(muted); setPadding(0, dp(12), 0, dp(6))
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 12f; isAllCaps = false; setTextColor(white)
        setBackgroundColor(Color.rgb(20, 72, 96)); setOnClickListener { action() }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { if (::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
